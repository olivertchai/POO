import Car from "../model/Car";

export default class Database{

    private carDb: Car[] = [];

    public addNewCar(car: Car): void {
        this.carDb.push(car);
        this.listAll();
    }
    public getCar(index: number): Car {
        return this.carDb[index];
    }

    public listAll(){
        for (let index = 0; index < this.carDb.length; index++) {
            const element = this.carDb[index];
            console.log("\n"+element.getModel()+"  "+element.getYear())
        }
    }


}