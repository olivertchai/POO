export default class Car{
   private model!: string;
   private year!: number;


   public getModel(): string{
      return this.model;
   }
   public setModel(model: string): void{
    this.model = model;
   }

   public getYear(): number{
      return this.year;
   }
   public setYear(year: number): void{
    this.year = year;
   }



}