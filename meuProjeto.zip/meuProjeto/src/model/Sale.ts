import Car from "./Car";
import Client from "./Client";

export default class Sale{
  

    public doSale(car: Car, client: Client){

    }


}