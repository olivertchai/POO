import MainController from "./controller/MainController";


new MainController();


